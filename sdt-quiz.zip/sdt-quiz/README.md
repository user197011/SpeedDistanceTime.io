# Speed · Distance · Time Quiz

A mobile-first quiz app with **2000 questions** across four categories — Speed, Distance, Time, and Unit Conversions. Supports whole number and decimal modes, with instant feedback, streak tracking, and full answer review.

## Features

- 🔢 **Whole numbers** mode — clean integer answers
- 🔣 **Decimals** mode — fractional values included
- 🎲 **4 categories** — Speed, Distance, Time, Conversions
- 🔀 **Rotated questions** — interleaved categories, anti-consecutive answer shuffling
- ✅ **Instant feedback** — Correct / Incorrect with working shown
- ↩ **Try again** — re-attempt wrong answers without affecting score
- 🔥 **Streak tracking** — best streak saved across sessions
- 📋 **Answer history** — full session review
- 📱 **Mobile-first** — 48px+ tap targets, no hover dependency
- 💾 **Persistent stats** — progress saved to localStorage
- 🌐 **PWA-ready** — can be added to home screen

## Login

Password: **HappyDTS**

The login page shows your saved stats (questions done, accuracy, best streak) before you sign in.

## Live Demo

> Once deployed: `https://<your-username>.github.io/sdt-quiz/`

---

## How to host on GitHub Pages

### Option 1 — GitHub web interface (easiest)

1. Go to [github.com](https://github.com) and sign in (or create a free account).
2. Click **New repository** (the green button or `+` icon).
3. Name it `sdt-quiz` (or anything you like).
4. Set it to **Public**, leave everything else as default, click **Create repository**.
5. On the next page click **uploading an existing file**.
6. Drag and drop these four files into the upload area:
   - `index.html`
   - `style.css`
   - `app.js`
   - `manifest.json`
7. Click **Commit changes**.
8. Go to **Settings → Pages** (in the left sidebar).
9. Under **Source**, select **Deploy from a branch**.
10. Under **Branch**, choose `main` and `/ (root)`, then click **Save**.
11. Wait ~60 seconds, then visit `https://<your-username>.github.io/sdt-quiz/`.

### Option 2 — GitHub CLI / Git (if you have git installed)

```bash
# 1. Create a new repo on GitHub first (via the website, step 1–4 above)

# 2. In the sdt-quiz folder, run:
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/sdt-quiz.git
git push -u origin main

# 3. Enable Pages in Settings → Pages → Branch: main / root
```

Your site will be live at `https://<your-username>.github.io/sdt-quiz/` within a minute or two.

---

## File structure

```
sdt-quiz/
├── index.html      ← App shell & all screen HTML
├── style.css       ← All styles (mobile-first)
├── app.js          ← Question bank, quiz logic, state management
├── manifest.json   ← PWA manifest (add-to-home-screen)
└── README.md       ← This file
```

## Optional: Add app icons

For the PWA to show a proper icon when added to a home screen, add two PNG files to the folder:

- `icon-192.png` — 192 × 192 px
- `icon-512.png` — 512 × 512 px

You can create a simple purple square with "SDT" text in any image editor.

---

## Customising

| What | Where |
|------|-------|
| Add more questions | `app.js` → `buildWhole()` / `buildDecimal()` — add pairs to the data arrays |
| Change colours | `style.css` — update the hex values near the top |
| Change number of questions per session | `app.js` → add a new `setQty()` call or change the `[10,20,50]` defaults |
| Change difficulty labels | `app.js` → `setDiff()` and the `diff` property on each question |

## Browser support

Works in all modern browsers: Chrome, Firefox, Safari, Edge. Tested on iOS Safari and Android Chrome.
